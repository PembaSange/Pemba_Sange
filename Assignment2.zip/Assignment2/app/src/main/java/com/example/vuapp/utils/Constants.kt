package com.example.vuapp.utils

object Constants {
    const val BASE_URL = "https://nit3213api.onrender.com/"
}
